TECHNOLOGY {
    type = "technology",
    name = "  ",
    icon = "  ",
    icon_size = 128,
    order = "  ",
    upgrade = true,
    prerequisites = {"  "},
    effects = {},
    unit = {
        count = 30,
        ingredients = {
            {"  ", 1}
        },
        time = 35
    }
}
