data:extend(
{
  {
    type = "fuel-category",
    name = "control-rod"
  },
  {
    type = "fuel-category",
    name = "microwave"
  },
  {
    type = "fuel-category",
    name = "quantum"
  },
}
)
