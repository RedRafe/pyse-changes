local FUN = require("__pycoalprocessing__/prototypes/functions/functions")

FUN.global_item_replacer("uranium-238", "u-238")
FUN.global_item_replacer("uranium-235", "u-235")
