return {
	['hawt-turbine-mk01'] = 0.5,
	['hawt-turbine-mk02'] = 0.5,
	['hawt-turbine-mk03'] = 0.5,
	['hawt-turbine-mk04'] = 0.5,
	['vawt-turbine-mk01'] = 0.7,
	['vawt-turbine-mk02'] = 0.7,
	['vawt-turbine-mk03'] = 0.7,
	['vawt-turbine-mk04'] = 0.7,
	['multiblade-turbine-mk01'] = 0.9,
	['multiblade-turbine-mk03'] = 0.8,
}
