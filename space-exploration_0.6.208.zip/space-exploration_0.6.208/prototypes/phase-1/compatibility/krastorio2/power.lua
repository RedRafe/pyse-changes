local data_util = require("data_util")

-- This source is dedicated to balancing Power production and distribution in SE and K2

-- fix power progression
-- higher tech means more power density
-- more complicated setups mean higher energy efficiency (closer to 1).
-- simpler setups mean reduced energy efficiency.

-- fuild isothermic generator is 0.75 normally
-- both convert fuel to energy directly so shouldn't be over 80% efficiency.
-- fuild isothermic generator is less space efficient.
data.raw["generator"]["kr-gas-power-station"].energy_source.effectivity = 0.75
data.raw["generator"]["kr-gas-power-station"].collsion_mask = --land
  {"item-layer","object-layer","player-layer","water-tile",space_collision_layer, spaceship_collision_layer}
data.raw["generator"]["se-fluid-burner-generator"].collsion_mask = --space
  {"water-tile","ground-tile","item-layer","object-layer","player-layer"}

-- Move K2 Energy Storage Tech to after Naquium Accumulator
data.raw.technology["kr-energy-storage"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("kr-energy-storage",{"electric-energy-accumulators","kr-energy-control-unit","kr-matter-tech-card"})
data_util.tech_add_prerequisites("kr-energy-storage",{"se-space-accumulator-2","se-naquium-processor"})
data_util.tech_add_ingredients("kr-energy-storage",{"automation-science-pack","logistic-science-pack","chemical-science-pack","advanced-tech-card","se-astronomic-science-pack-4","se-energy-science-pack-4","se-material-science-pack-4","se-deep-space-science-pack-3"})

-- Improve Energy Storage entity to account for now being the final accumulator
if data.raw.accumulator["kr-energy-storage"] then
	local accu = data.raw.accumulator["kr-energy-storage"]
	-- Pretty sure this might be OP, but hey, we're at DSS3 here.
	accu.energy_source = {
		type = "electric",
		buffer_capacity = "5000MJ",
		usage_priority = "tertiary",
		input_flow_limit = "10MW",
		output_flow_limit = "50MW"
	}
end

-- Increase cost Energy Storage recipe to account for now being the final accumulator
data.raw.recipe["kr-energy-storage"].ingredients = {
	{"se-naquium-plate", 20},
	{"se-naquium-heat-pipe", 10},
	{"se-naquium-processor", 4},
	{"se-space-accumulator-2", 10}
}

data.raw.recipe["kr-energy-storage"].subgroup = "solar"
data.raw.recipe["kr-energy-storage"].order = "e[accumulator]-a[accumulator]-final"
data.raw.recipe["kr-energy-storage"].category = "space-manufacturing"

data.raw.item["kr-energy-storage"].subgroup = "solar"
data.raw.item["kr-energy-storage"].order = "e[accumulator]-a[accumulator]-final"

-- Adjust techs so that K2 Solar Panel has the correct costs for it's position in the tech tree.
data.raw.technology["kr-advanced-solar-panel"].check_science_packs_incompatibilities = false
data_util.tech_add_prerequisites("kr-advanced-solar-panel",{"kr-optimization-tech-card"})
data_util.tech_add_ingredients("kr-advanced-solar-panel", {"space-science-pack","kr-optimization-tech-card"})
data_util.tech_remove_ingredients("kr-advanced-solar-panel",{"production-science-pack"})

-- Adjust techs so that K2 Solar Panel is required for Flat Solar Panel
data.raw.technology["se-space-solar-panel"].check_science_packs_incompatibilities = false
data_util.tech_remove_prerequisites("se-space-solar-panel", {"space-science-pack"})
data_util.tech_add_prerequisites("se-space-solar-panel",{"kr-advanced-solar-panel","se-holmium-cable"})
data_util.tech_add_ingredients("se-space-solar-panel", {"se-energy-science-pack-1"})

-- Adjust costs of Flat Solar Panel
data_util.replace_or_add_ingredient("se-space-solar-panel","solar-panel","kr-advanced-solar-panel",1)
data_util.replace_or_add_ingredient("se-space-solar-panel", nil, "se-holmium-cable", 4)
data_util.replace_or_add_ingredient("se-space-solar-panel", nil, "se-holmium-plate", 4)

-- Adjust prototypes so that Flat Solar Panel upgrades from K2 Solar Panel
local se_space_solar_panel = data.raw["solar-panel"]["se-space-solar-panel"]
data.raw["solar-panel"]["kr-advanced-solar-panel"].fast_replaceable_group = se_space_solar_panel.fast_replaceable_group
data.raw["solar-panel"]["kr-advanced-solar-panel"].collision_box = se_space_solar_panel.collision_box
data.raw["solar-panel"]["kr-advanced-solar-panel"].collision_mask = se_space_solar_panel.collision_mask
data.raw["solar-panel"]["kr-advanced-solar-panel"].next_upgrade = "se-space-solar-panel"

-- Reorder K2 Solar Panel to be with other solar panels.
data.raw.recipe["kr-advanced-solar-panel"].subgroup = "solar"
data.raw.recipe["kr-advanced-solar-panel"].order = "d[solar-panel]-a[solar-panel]-a"

data.raw.item["kr-advanced-solar-panel"].subgroup = "solar"
data.raw.item["kr-advanced-solar-panel"].order = "d[solar-panel]-a[solar-panel]-a"

-- Adjust costs and tech requirement of Flat Solar Panel 2
data_util.tech_remove_prerequisites("se-space-solar-planel-2", {"se-holmium-cable"})
data_util.tech_remove_ingredients("se-space-solar-panel-2", {"se-energy-science-pack-1"})
data_util.tech_add_prerequisites("se-space-solar-panel-2", {"se-holmium-solenoid","se-aeroframe-scaffold"})
data_util.tech_add_ingredients("se-space-solar-panel-2", {"se-energy-science-pack-2","se-astronomic-science-pack-2"})

data_util.replace_or_add_ingredient("se-space-solar-panel-2", "se-holmium-plate", "se-holmium-solenoid", 2)
data_util.replace_or_add_ingredient("se-space-solar-panel-2", "se-space-mirror", "se-aeroframe-scaffold", 2)