local data_util = require("data_util")

data_util.tech_remove_ingredients("battery-mk2-equipment",{"utility-science-pack"})
data_util.tech_remove_prerequisites("inserter-capacity-bonus-4",{"production-science-pack"})
data_util.tech_add_prerequisites("inserter-capacity-bonus-4",{"space-science-pack"})
data_util.tech_add_prerequisites("inserter-capacity-bonus-5",{"production-science-pack"})
data_util.tech_remove_prerequisites("mining-productivity-3",{"utility-science-pack","production-science-pack"})
data_util.tech_remove_prerequisites("refined-flammables-4",{"utility-science-pack"})
data_util.tech_remove_prerequisites("stronger-explosives-4",{"utility-science-pack"})
data_util.tech_remove_prerequisites("worker-robots-speed-3",{"utility-science-pack"})
data_util.tech_add_prerequisites("worker-robots-speed-3",{"se-thruster-suit"})
data_util.tech_remove_prerequisites("worker-robots-speed-5",{"production-science-pack"})

-- Remove "radar" tech / replace with "kr-radar" tech
data_util.tech_lock_recipes("kr-radar",{"radar"})
data_util.tech_add_prerequisites("rocket-silo",{"kr-radar"})
data_util.tech_remove_prerequisites("rocket-silo",{"radar"})
data.raw.technology["radar"] = nil

-- Replace "se-fuel-refining" with "kr-fuel" tech
data_util.tech_add_prerequisites("rocket-fuel",{"kr-fuel"})
data_util.tech_remove_prerequisites("rocket-fuel",{"se-fuel-refining"})
data_util.tech_add_prerequisites("speed-module",{"kr-fuel"})
data_util.tech_remove_prerequisites("speed-module",{"se-fuel-refining"})

data_util.tech_lock_recipes("kr-fuel",{"solid-fuel-from-heavy-oil","solid-fuel-from-light-oil","solid-fuel-from-petroleum-gas"})
data_util.tech_add_prerequisites("se-fuel-refining",{"kr-fuel"})
data_util.tech_remove_prerequisites("se-fuel-refining",{"oil-processing","logistic-science-pack"})

-- Repurpose "se-fuel-refining" tech and building as an advanced option.
data_util.tech_add_prerequisites("se-fuel-refining", {"space-science-pack"})
data_util.tech_add_ingredients("se-fuel-refining", {"chemical-science-pack","se-rocket-science-pack","space-science-pack"})
data_util.tech_remove_ingredients("se-fuel-refining",{"basic-tech-card"})

local se_fuel_refinery = data.raw["assembling-machine"]["se-fuel-refinery"]
local se_fuel_refinery_spaced = data.raw["assembling-machine"]["se-fuel-refinery-spaced"]
local kr_fuel_refinery = data.raw["assembling-machine"]["kr-fuel-refinery"]

-- Slightly better specification to start with
se_fuel_refinery.module_specification = {module_slots = 4}
se_fuel_refinery.crafting_speed = 2
se_fuel_refinery.energy_usage = "2500kW"

-- Give both fuel refineries the same recipe categories
table.insert(se_fuel_refinery.crafting_categories, "fuel-refinery")
table.insert(kr_fuel_refinery.crafting_categories, "fuel-refining")

-- Update the spaced version of the SE Fuel Refinery
if se_fuel_refinery_spaced then
  if se_fuel_refinery_spaced.module_specification then
    se_fuel_refinery_spaced.module_specification.module_slots = 4
  else
    se_fuel_refinery_spaced.module_specification = {module_slots = 4}
  end
  se_fuel_refinery_spaced.crafting_speed = 2
  se_fuel_refinery_spaced.energy_usage = "2500kW"

  table.insert(se_fuel_refinery_spaced.crafting_categories, "fuel-refinery")
end

local function move_technology(tech_name, techs_to_add, ingredients_to_add, techs_to_remove, ingredients_to_remove)
  if ingredients_to_remove then
    data_util.tech_remove_ingredients(tech_name, ingredients_to_remove)
  end
  if techs_to_remove then
    data_util.tech_remove_prerequisites(tech_name, techs_to_remove)
  end
  if ingredients_to_add then
    data_util.tech_add_ingredients(tech_name, ingredients_to_add)
  end
  if techs_to_add then
    data_util.tech_add_prerequisites(tech_name, techs_to_add)
  end
end
---- Lab Research Speed ----

move_technology(
  "research-speed-3",
  {"laser"},
  nil,
  {"chemical-science-pack"}
)

move_technology(
  "research-speed-4",
  {"automation-3"},
  nil,
  {"space-science-pack"}
)

move_technology(
  "research-speed-5",
  {"kr-optimization-tech-card"},
  {"kr-optimization-tech-card"},
  {"utility-science-pack","production-science-pack"},
  {"utility-science-pack"}
)

move_technology(
  "research-speed-6",
  {"se-space-simulation-asbm"},
  {"kr-optimization-tech-card","production-science-pack","se-material-science-pack-1","se-astronomic-science-pack-1","se-biological-science-pack-1"},
  {"se-energy-science-pack-1","utility-science-pack"}
)

---- Train Braking Force ----

move_technology(
  "braking-force-1",
  {"se-heat-shielding"},
  nil,
  {"space-science-pack"}
)

move_technology(
  "braking-force-3",
  data.raw["technology"]["kr-nuclear-locomotive"] and {"kr-nuclear-locomotive"} or nil,
  nil,
  {"production-science-pack"}
)

move_technology(
  "braking-force-6",
  {"kr-logistic-4"},
  nil,
  {"se-material-science-pack-1"}
)

move_technology(
  "braking-force-7",
  {"kr-logistic-5"},
  nil,
  {"se-material-science-pack-2"}
)

---- Weapon Shooting Speed ----

move_technology(
  "weapon-shooting-speed-2",
  {"military-2"},
  nil,
  {"logistic-science-pack"}
)

move_technology(
  "weapon-shooting-speed-3",
  {"defender"},
  nil,
  {"military-science-pack"}
)

move_technology(
  "weapon-shooting-speed-4",
  {"military-3"},
  nil,
  {"chemical-science-pack"}
)

move_technology(
  "weapon-shooting-speed-5",
  {"destroyer"},
  nil,
  {"space-science-pack"}
)

move_technology(
  "weapon-shooting-speed-6",
  {"se-railgun"},
  nil,
  {"se-material-science-pack-1"}
)

---- Laser Shooting Speed ----

move_technology(
  "laser-shooting-speed-1",
  {"laser-turret"},
  nil,
  {"military-science-pack"}
)

move_technology(
  "laser-shooting-speed-3",
  {"military-4"},
  nil,
  {"space-science-pack"}
)

move_technology(
  "laser-shooting-speed-5",
  {"se-space-laser-laboratory"},
  nil,
  {"utility-science-pack"}
)

move_technology(
  "laser-shooting-speed-6",
  {"kr-imersite-weapons"},
  nil,
  {"se-energy-science-pack-1"}
)

move_technology(
  "laser-shooting-speed-7",
  {"kr-personal-laser-defense-mk3-equipment"},
  nil,
  {"se-energy-science-pack-2"}
)

---- Inserter Capacity Bonus ----

move_technology(
  "inserter-capacity-bonus-3",
  {"low-density-structure"},
  nil,
  {"chemical-science-pack"}
)

move_technology(
  "inserter-capacity-bonus-5",
  {"logistics-3"},
  nil,
  {"space-science-pack"}
)

if krastorio.general.getSafeSettingValue("kr-containers") then
  move_technology(
    "inserter-capacity-bonus-7",
    {"kr-logistic-containers-2"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
else
  move_technology(
    "inserter-capacity-bonus-7",
    {"utility-science-pack"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
end

move_technology(
  "inserter-capacity-bonus-8",
  {"kr-logistic-4"},
  {"utility-science-pack"},
  {"se-material-science-pack-1"}
)

---- Toolbelt ----

move_technology(
  "toolbelt-3",
  {"low-density-structure"},
  nil,
  {"chemical-science-pack"}
)

move_technology(
  "toolbelt-4",
  {"logistics-3"},
  nil,
  {"space-science-pack"}
)

if krastorio.general.getSafeSettingValue("kr-containers") then
  move_technology(
    "toolbelt-5",
    {"kr-logistic-containers-2"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
else
  move_technology(
    "toolbelt-5",
    {"utility-science-pack"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
end

move_technology(
  "toolbelt-6",
  {"kr-logistic-4"},
  {"utility-science-pack"},
  {"se-material-science-pack-1"}
)

---- Worker Robot Cargo Size ----

move_technology(
  "worker-robots-storage-1",
  {"logistics-3"},
  nil,
  {"space-science-pack"}
)

if krastorio.general.getSafeSettingValue("kr-containers") then
  move_technology(
    "worker-robots-storage-2",
    {"kr-logistic-containers-2"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
else
  move_technology(
    "worker-robots-storage-2",
    {"utility-science-pack"},
    {"utility-science-pack"},
    {"production-science-pack"}
  )
end

move_technology(
  "worker-robots-storage-3",
  {"kr-logistic-4"},
  {"utility-science-pack"},
  {"se-material-science-pack-1"}
)