local data_util = require("data_util")

local recipe = data.raw.recipe
local tech = data.raw.technology
local fluid = data.raw.fluid

  --Add various K2 products to the delivery cannon.
se_delivery_cannon_recipes = se_delivery_cannon_recipes or {}

se_delivery_cannon_recipes["mineral-water"] = {name="mineral-water-barrel"}
se_delivery_cannon_recipes["biomethanol"] = {name="biomethanol-barrel"}
se_delivery_cannon_recipes["chlorine"] = {name="chlorine-barrel"}
se_delivery_cannon_recipes["dirty-water"] = {name="dirty-water-barrel"}
se_delivery_cannon_recipes["heavy-water"] = {name="heavy-water-barrel"}
se_delivery_cannon_recipes["hydrogen-chloride"] = {name="hydrogen-chloride-barrel"}
se_delivery_cannon_recipes["nitric-acid"] = {name="nitric-acid-barrel"}

se_delivery_cannon_recipes["raw-imersite"] = {name="raw-imersite"}
se_delivery_cannon_recipes["imersium-plate"] = {name="imersium-plate"}
se_delivery_cannon_recipes["imersite-crystal"] = {name="imersite-crystal"}
se_delivery_cannon_recipes["coke"] = {name="coke"}
se_delivery_cannon_recipes["quartz"] = {name="quartz"}
se_delivery_cannon_recipes["silicon"] = {name="silicon"}
se_delivery_cannon_recipes["enriched-iron"] = {name="enriched-iron"}
se_delivery_cannon_recipes["enriched-copper"] = {name="enriched-copper"}
se_delivery_cannon_recipes["enriched-rare-metals"] = {name="enriched-rare-metals"}
se_delivery_cannon_recipes["raw-rare-metals"] = {name="raw-rare-metals"}
se_delivery_cannon_recipes["rare-metals"] = {name="rare-metals"}
se_delivery_cannon_recipes["lithium"] = {name="lithium"}
se_delivery_cannon_recipes["lithium-chloride"] = {name="lithium-chloride"}
se_delivery_cannon_recipes["tritium"] = {name="tritium"}
se_delivery_cannon_recipes["fuel"] = {name="fuel"}
se_delivery_cannon_recipes["bio-fuel"] = {name="bio-fuel"}
se_delivery_cannon_recipes["advanced-fuel"] = {name="advanced-fuel"}
se_delivery_cannon_recipes["fertilizer"] = {name="fertilizer"}

-- N.B. The DSS and Matter Science Packs both require 2 fluid inputs, base K2 prototypes for the Server buildings only has 1 input, but can support 2
local fluid_box_1 = table.deepcopy(data.raw["assembling-machine"]["kr-research-server"].fluid_boxes[1])
local fluid_box_2 = table.deepcopy(data.raw["assembling-machine"]["kr-research-server"].fluid_boxes[2])
fluid_box_1.pipe_connections = { { type = "input", position = { -2, 0 } } }
fluid_box_2.pipe_connections = { { type = "output", position = { 2, 0 } } }

table.insert(data.raw["assembling-machine"]["kr-research-server"].fluid_boxes, fluid_box_1)
table.insert(data.raw["assembling-machine"]["kr-research-server"].fluid_boxes, fluid_box_2)

local fluid_box_3 = table.deepcopy(data.raw["assembling-machine"]["kr-quantum-computer"].fluid_boxes[1])
local fluid_box_4 = table.deepcopy(data.raw["assembling-machine"]["kr-quantum-computer"].fluid_boxes[2])
fluid_box_3.pipe_connections = { { type = "input", position = { -3.5, 0.5 } } }
fluid_box_4.pipe_connections = { { type = "output", position = { 3.5, -0.5 } } }

table.insert(data.raw["assembling-machine"]["kr-quantum-computer"].fluid_boxes, fluid_box_3)
table.insert(data.raw["assembling-machine"]["kr-quantum-computer"].fluid_boxes, fluid_box_4)

-- Add categories to K2 Research Server and Quantum Computer (Advanced Research Server)
local catalog_1 = "catalogue-creation-1"
local catalog_2 = "catalogue-creation-2"
local science_1 = "science-pack-creation-1"
local science_2 = "science-pack-creation-2"
data:extend({
  { type = "recipe-category", name = catalog_1 },
  { type = "recipe-category", name = catalog_2 },
  { type = "recipe-category", name = science_1 },
  { type = "recipe-category", name = science_2 },
})

-- Research Server
local exclude_categories = {"research-data","t2-tech-cards","t3-tech-cards"}
local research_server_categories = {catalog_1,science_1}
local quantum_computer_categories = {catalog_1,catalog_2,science_1,science_2}

for _, category in pairs(data.raw["assembling-machine"]["kr-research-server"].crafting_categories) do
  if not data_util.table_contains(exclude_categories,category) then
    table.insert(research_server_categories, category)
  end
end
data.raw["assembling-machine"]["kr-research-server"].crafting_categories = research_server_categories

for _, category in pairs(data.raw["assembling-machine"]["kr-quantum-computer"].crafting_categories) do
  if not data_util.table_contains(exclude_categories,category) then
    table.insert(quantum_computer_categories, category)
  end
end
data.raw["assembling-machine"]["kr-quantum-computer"].crafting_categories = quantum_computer_categories

-- Add recipes to these new categories
recipe["se-astronomic-catalogue-1"].category = catalog_1
recipe["se-astronomic-catalogue-2"].category = catalog_1
recipe["se-astronomic-catalogue-3"].category = catalog_1
recipe["se-astronomic-catalogue-4"].category = catalog_1
recipe["se-biological-catalogue-1"].category = catalog_1
recipe["se-biological-catalogue-2"].category = catalog_1
recipe["se-biological-catalogue-3"].category = catalog_1
recipe["se-biological-catalogue-4"].category = catalog_1
recipe["se-energy-catalogue-1"].category = catalog_1
recipe["se-energy-catalogue-2"].category = catalog_1
recipe["se-energy-catalogue-3"].category = catalog_1
recipe["se-energy-catalogue-4"].category = catalog_1
recipe["se-material-catalogue-1"].category = catalog_1
recipe["se-material-catalogue-2"].category = catalog_1
recipe["se-material-catalogue-3"].category = catalog_1
recipe["se-material-catalogue-4"].category = catalog_1

recipe["se-deep-catalogue-1"].category = catalog_2
recipe["se-deep-catalogue-2"].category = catalog_2
recipe["se-deep-catalogue-3"].category = catalog_2
recipe["se-deep-catalogue-4"].category = catalog_2

recipe["se-astronomic-science-pack-1"].category = science_1
--recipe["se-astronomic-science-pack-1-no-beryllium"].category = science_1
recipe["se-astronomic-science-pack-2"].category = science_1
recipe["se-astronomic-science-pack-3"].category = science_1
recipe["se-astronomic-science-pack-4"].category = science_1
recipe["se-biological-science-pack-1"].category = science_1
recipe["se-biological-science-pack-2"].category = science_1
recipe["se-biological-science-pack-3"].category = science_1
recipe["se-biological-science-pack-4"].category = science_1
recipe["se-energy-science-pack-1"].category = science_1
recipe["se-energy-science-pack-2"].category = science_1
recipe["se-energy-science-pack-3"].category = science_1
recipe["se-energy-science-pack-4"].category = science_1
recipe["se-material-science-pack-1"].category = science_1
recipe["se-material-science-pack-2"].category = science_1
recipe["se-material-science-pack-3"].category = science_1
recipe["se-material-science-pack-4"].category = science_1

recipe["se-deep-space-science-pack-1"].category = science_2
recipe["se-deep-space-science-pack-2"].category = science_2
recipe["se-deep-space-science-pack-3"].category = science_2
recipe["se-deep-space-science-pack-4"].category = science_2

-- Additionally, since the pack creation recipes previously took place in a 10 crafting speed machine, adjust time to craft down.
-- The servers consume much higher power per crafting speed as well, so science packs now cost more energy to craft too.
-- The servers also have fewer module slots, so their moduled and beaconed top speed is lower than a top speed manufactury as well.
local time_factor = 6 -- Arbitrary factor, can be changed as required for balance
recipe["se-astronomic-science-pack-1"].energy_required = recipe["se-astronomic-science-pack-1"].energy_required / time_factor
--recipe["se-astronomic-science-pack-1-no-beryllium"].energy_required = recipe["se-astronomic-science-pack-1-no-beryllium"].energy_required / time_factor
recipe["se-astronomic-science-pack-2"].energy_required = recipe["se-astronomic-science-pack-2"].energy_required / time_factor
recipe["se-astronomic-science-pack-3"].energy_required = recipe["se-astronomic-science-pack-3"].energy_required / time_factor
recipe["se-astronomic-science-pack-4"].energy_required = recipe["se-astronomic-science-pack-4"].energy_required / time_factor
recipe["se-biological-science-pack-1"].energy_required = recipe["se-biological-science-pack-1"].energy_required / time_factor
recipe["se-biological-science-pack-2"].energy_required = recipe["se-biological-science-pack-2"].energy_required / time_factor
recipe["se-biological-science-pack-3"].energy_required = recipe["se-biological-science-pack-3"].energy_required / time_factor
recipe["se-biological-science-pack-4"].energy_required = recipe["se-biological-science-pack-4"].energy_required / time_factor
recipe["se-energy-science-pack-1"].energy_required = recipe["se-energy-science-pack-1"].energy_required / time_factor
recipe["se-energy-science-pack-2"].energy_required = recipe["se-energy-science-pack-2"].energy_required / time_factor
recipe["se-energy-science-pack-3"].energy_required = recipe["se-energy-science-pack-3"].energy_required / time_factor
recipe["se-energy-science-pack-4"].energy_required = recipe["se-energy-science-pack-4"].energy_required / time_factor
recipe["se-material-science-pack-1"].energy_required = recipe["se-material-science-pack-1"].energy_required / time_factor
recipe["se-material-science-pack-2"].energy_required = recipe["se-material-science-pack-2"].energy_required / time_factor
recipe["se-material-science-pack-3"].energy_required = recipe["se-material-science-pack-3"].energy_required / time_factor
recipe["se-material-science-pack-4"].energy_required = recipe["se-material-science-pack-4"].energy_required / time_factor

recipe["se-deep-space-science-pack-1"].energy_required = recipe["se-deep-space-science-pack-1"].energy_required / time_factor
recipe["se-deep-space-science-pack-2"].energy_required = recipe["se-deep-space-science-pack-2"].energy_required / time_factor
recipe["se-deep-space-science-pack-3"].energy_required = recipe["se-deep-space-science-pack-3"].energy_required / time_factor
recipe["se-deep-space-science-pack-4"].energy_required = recipe["se-deep-space-science-pack-4"].energy_required / time_factor

-- Landfill recipes -- needs to be in phase 2
local template = data.raw.recipe["landfill-iron-ore"]
local tech = data.raw.technology["se-recycling-facility"]

for _, resource_name in pairs({"raw-rare-metals","raw-imersite"}) do
  local recipe = table.deepcopy(template)
  recipe.name = "landfill-" .. resource_name
  recipe.order = "z-b-" .. resource_name
  recipe.icon = nil
  recipe.icons = {
    { icon = data.raw.item["landfill"].icon, icon_size = data.raw.item["landfill"].icon_size },
    { icon = data.raw.item[resource_name].icon, icon_size = data.raw.item[resource_name].icon_size, scale = 0.33 },
  }
  if recipe.ingredients then
    recipe.ingredients = { { name = resource_name, amount = 50 } }
  end
  if recipe.normal and recipe.normal.ingredients then
    recipe.normal.ingredients = { { name = resource_name, amount = 50 } }
  end
  if recipe.expensive and recipe.expensive.ingredients then
    recipe.expensive.ingredients = { { name = resource_name, amount = 50 } }
  end
  table.insert(tech.effects, { type = "unlock-recipe", recipe = recipe.name })
  data:extend({ recipe })
end

-- Solar Panel recipe
data_util.replace_or_add_ingredient("solar-panel","glass","glass",15)

-- Crusher does Crushing, not as fine a result as the pulveriser?

-- Merge the Sand/Glass recipes
data_util.tech_lock_recipes("kr-stone-processing",{"sand-from-stone"})
data.raw.recipe["sand-from-stone"].category = "crushing"

data_util.tech_lock_recipes("se-pulveriser",{"sand"})
data.raw.recipe["sand"].category = "pulverising"