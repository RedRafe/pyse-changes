local data_util = require("data_util")

if mods["Krastorio2"] then

    -- Certain changes made by Krastorio 2 to Vanilla items and recipes occur in the data-update lifecycle phase (phase-2) and we can only adjust them here or in postprocess.
    -- Changes should only be made in this phase if those changes cannot be made in data (phase-1) or data-update (phase-2)
    require("prototypes/phase-3/compatibility/krastorio2/modules")
    require("prototypes/phase-3/compatibility/krastorio2/resource-processing")
    require("prototypes/phase-3/compatibility/krastorio2/inserters")
    require("prototypes/phase-3/compatibility/krastorio2/technology")
    require("prototypes/phase-3/compatibility/krastorio2/recipes")
    require("prototypes/phase-3/compatibility/krastorio2/equipment")
    require("prototypes/phase-3/compatibility/krastorio2/infinite-techs")
    require("prototypes/phase-3/compatibility/krastorio2/science-labs")

    -- Enforce aspects of Rocekt Fuel balance
    require("prototypes/phase-3/compatibility/krastorio2/rocket-fuel")
end