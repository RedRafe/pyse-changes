
data:extend({
  -- Create new item group for basic matter recipes
    {
      type = "recipe-category",
      name = "advanced-particle-stream"
    },
    {
      type = "item-subgroup",
      name = "advanced-particle-stream",
      group = "intermediate-products",
      order = "z-h-b"
    },
    {
      type = "recipe-category",
      name = "basic-matter-conversion"
    },
    {
      type = "item-subgroup",
      name = "basic-matter-conversion",
      group = "intermediate-products",
      order = "m0"
    },
    {
      type = "recipe-category",
      name = "advanced-matter-conversion"
    },
    {
      type = "item-subgroup",
      name = "advanced-matter-conversion",
      group = "intermediate-products",
      order = "m2"
    },
    {
      type = "recipe-category",
      name = "basic-matter-deconversion"
    },
    {
      type = "item-subgroup",
      name = "basic-matter-deconversion",
      group = "intermediate-products",
      order = "m0"
    },
    {
      type = "recipe-category",
      name = "advanced-matter-deconversion"
    },
    {
      type = "item-subgroup",
      name = "advanced-matter-deconversion",
      group = "intermediate-products",
      order = "m2"
    },
    {
      type = "recipe-category",
      name = "atmosphere-condensation-water"
    },
  -- Create Item subgroups for K2 resource recipe reordering to be inline with SE resource recipe ordering
    {
      type = "item-subgroup",
      name = "rare-metals",
      group = "resources",
      order = "a-h-c"
    },
    {
      type = "item-subgroup",
      name = "imersite",
      group = "resources",
      order = "a-k-b"
    },
    {
      type = "item-subgroup",
      name = "lithium",
      group = "resources",
      order = "a-h-d"
    },
  })

-- Reorder the K2 Warehouse subgroups.
data.raw["item-subgroup"]["kr-logistics-2"].order = "a3[container-3]"
data.raw["item-subgroup"]["kr-logistics-3"].order = "a6[container-6-b]"