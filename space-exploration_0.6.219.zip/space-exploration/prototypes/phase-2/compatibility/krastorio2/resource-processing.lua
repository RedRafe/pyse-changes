local data_util = require("data_util")

-- This source is dedicated to maintaining compatability changes required for the K2 and SE resource processing steps.
-- E.G.
--  - Making sure K2 enrichment and SE molten metal casting are both available and the recipe amounts make sense as progressive levels of plate production efficiency
--  - Introducing changes to Iridium and Holomium to include the K2 Washing loop.

-- Make the Iridium and Holmium processing changes.
require("washing")

---- Copper Plates ----

-- SE
-- 1st Tier: 1 Copper Ore = 1 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 1.5 Copper Plate
--     24 Copper Ore processed with 10 Pyroflux to 900 Molten Copper
--     250 Molten Copper cast to 1 Copper Ingot
--     1 Copper Ingots processed to 10 Copper Plates

-- K2
-- 1st Tier: 1 Copper Ore = 0.5 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 0.667 Copper Plate
--     9 Copper Ore processed with 3 Sulfuric Acid to 6 Enriched Copper Ore
--     5 Enriched Copper Ore to 5 Copper Plates

-- SE-K2
-- 1st Tier: 1 Copper Ore = 0.75 Copper Plate, Copper Ore directly smelted to Copper Plates
-- 2nd Tier: 1 Copper Ore = 1 Copper Plate
--     9 Copper Ore processed with 3 Sulfuric Acid to 9 Enriched Copper Ore
--     5 Enriched Copper Ore to 5 Copper Plates
-- 3rd Tier: 1 Copper Ore = 1.25 Copper Plate -- Less than SE efficiency due to additional productivity steps being possible
--     9 Copper Ore processed with 3 Sulfuric Acid to 9 Enriched Copper Ore
--     24 Enriched Copper Ore processed with 10 Pyroflux to 750 Molten Copper
--     250 Molten Copper cast to 1 Copper Ingot
--     1 Copper Ingot processed to 10 Copper Plates

-- Krastorio 2 overwrites these changes after this point and so they will be applied in space-exploration/prototypes/phase-3/compatibility/krastorio2/resource-processing
-- -- Copper Ore smelting recipe
-- data_util.replace_or_add_ingredient("copper-plate", "copper-ore", "copper-ore", 20)
-- data_util.replace_or_add_result("copper-plate", "copper-plate", "copper-plate", 15)

-- Enriched Copper Ore recipe
data_util.replace_or_add_result("enriched-copper", "enriched-copper", "enriched-copper", 9)

-- Molten Copper recipe
data.raw.recipe["se-molten-copper"].ingredients = {
    {name = "enriched-copper", amount = 24},
    {type = "fluid", name = "se-pyroflux", amount = 10},
}
data.raw.recipe["se-molten-copper"].results = {
    {type = "fluid", name = "se-molten-copper", amount = 750},
}

-- Update K2s Copper recipes to share the same subgroup as SEs Copper recipes
data.raw.item["enriched-copper"].subgroup = "copper"
data.raw.item["enriched-copper"].order = "a-a"
data.raw.recipe["enriched-copper"].subgroup = "copper"
data.raw.recipe["enriched-copper"].order = "a-1"
data.raw.recipe["dirty-water-filtration-2"].subgroup = "copper"
data.raw.recipe["dirty-water-filtration-2"].order = "a-2"

---- Iron Plates ----

-- SE
-- 1st Tier: 1 Iron Ore = 1 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 1.5 Iron Plate
--     24 Iron Ore processed with 10 Pyroflux to 900 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingots processed to 10 Iron Plates

-- K2
-- 1st Tier: 1 Iron Ore = 0.5 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 0.667 Iron Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 6 Enriched Iron Ore
--     5 Enriched Iron Ore to 5 Iron Plates

-- SE-K2
-- 1st Tier: 1 Iron Ore = 0.75 Iron Plate, Iron Ore directly smelted to Iron Plates
-- 2nd Tier: 1 Iron Ore = 1 Iron Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     5 Enriched Iron Ore to 5 Iron Plates
-- 3rd Tier: 1 Iron Ore = 1.25 Iron Plate -- Less than SE efficiency due to additional productivity steps being possible
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates

-- Krastorio 2 overwrites these changes after this point and so they will be applied in space-exploration/prototypes/phase-3/compatibility/krastorio2/resource-processing
-- Iron Ore smelting recipe
-- data_util.replace_or_add_ingredient("iron-plate", "iron-ore", "iron-ore", 20)
-- data_util.replace_or_add_result("iron-plate", "iron-plate", "iron-plate", 15)

-- Enriched Iron Ore recipe
data_util.replace_or_add_result("enriched-iron", "enriched-iron", "enriched-iron", 9)

-- Molten Iron recipe
data.raw.recipe["se-molten-iron"].ingredients = {
    {name = "enriched-iron", amount = 24},
    {type = "fluid", name = "se-pyroflux", amount = 10},
}
data.raw.recipe["se-molten-iron"].results = {
    {type = "fluid", name = "se-molten-iron", amount = 750},
}

-- Update K2s recipes Iron recipes to share the same subgroup as SEs Iron recipes
data.raw.item["enriched-iron"].subgroup = "iron"
data.raw.item["enriched-iron"].order = "a-a"
data.raw.recipe["enriched-iron"].subgroup = "iron"
data.raw.recipe["enriched-iron"].order = "a-1"
data.raw.recipe["dirty-water-filtration-1"].subgroup = "iron"
data.raw.recipe["dirty-water-filtration-1"].order = "a-2"

---- Steel Plates ----

-- SE
-- 1st Tier: 1 Iron Ore = 0.2 Steel Plate
--     1 Iron Ore smelted to 1 Iron Plate
--     5 Iron Plate smelted to 1 Steel Plate
-- 2nd Tier: 1 Iron Ore = 0.3 Steel Plate -- Possible unnecessary to consider given 3rd Tier is unlocked at the same time.
--     24 Iron Ore processed with 10 Pyroflux to 900 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates
--     5 Iron Plates smelted to 1 Steel Plate
-- 3rd Tier: 1 Iron Ore = 0.75 Steel Plate
--     24 Iron Ore processed with 10 Pyroflud to 900 Molten Iron
--     500 Molten Iron processed with 8 Coal into 1 Steel Ingot
--     1 Steel Ingot processed to 10 Steel Plate

-- K2
-- 1st Tier: 1 Iron Ore = 0.25 Steel Plate
--     10 Iron Ore Smelted to 5 Iron Plate
--     10 Iron Plate processed with 2 Coke to 5 Steel Plate
-- 2nd Tier: 1 Iron Ore = 0.33.. Steel Plate
--     9 Iron Ore Processed with 3 Sulfuric Acid to 6 Enriched Iron Ore
--     5 Enriched Iron Ore smelted to 5 Iron Plate
--     10 Iron Plate processed with 2 Coke to 5 Steel Plate

-- SE-K2
-- 1st Tier: 1 Iron Ore = 0.25 Steel Plate
--     20 Iron Ore smelted to 15 Iron Plates
--     15 Iron Plates processed with 3 Coke to 5 Steel Plates
-- 2nd Tier: 1 Iron Ore = 0.33.. Steel Plate?
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     5 Enriched Iron Ore smelted to 5 Iron Plate
--     15 Iron Plate processed with 3 Coke to 5 Steel Plate
-- 3rd Tier: 1 Iron Ore = 0.4166.. Steel Plate
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     250 Molten Iron cast to 1 Iron Ingot
--     1 Iron Ingot processed to 10 Iron Plates
--     15 Iron Plates processed with 3 Coke to 5 Steel Plates
-- 4th Tier: 1 Iron Ore = 0.625 Steel Plate -- Less than SE Efficiency due to additional Productivity steps being possible
--     9 Iron Ore processed with 3 Sulfuric Acid to 9 Enriched Iron Ore
--     24 Enriched Iron Ore processed with 10 Pyroflux to 750 Molten Iron
--     500 Molten Iron processed with 6 Coke into 1 Steel Ingot
--     1 Steel Ingot processed into 10 Steel Plate

-- Krastorio 2 overwrites these changes after this point and so they will be applied in space-exploration/prototypes/phase-3/compatibility/krastorio2/resource-processing
-- -- Steel Plate from Iron Plate
-- data_util.replace_or_add_ingredient("steel-plate","iron-plate","iron-plate",15)
-- data_util.replace_or_add_ingredient("steel-plate","coke","coke",3)

-- Steel Ingot From Molten Iron
data_util.replace_or_add_ingredient("se-steel-ingot","coal","coke",6)

---- Rare Metals ----

-- K2
-- 1st Tier: 1 Raw Rare Metals = 0.5 Rare Metals, Raw Rare Metals directly smelted to Rare Metals
-- 2nd Tier: 1 Raw Rare Metals = 0.667 Rare Metals
--     9 Raw Rare Metals processed with 10 Hydrogen Chloride to 6 Enriched Rare Metals
--     5 Enriched Rare Metals to 5 Rare Metals

-- SE-K2
-- 1st Tier: 1 Raw Rare Metals = 0.5 Rare Metals, Raw Rare Metals directly smelted to Rare Metals
-- 2nd Tier: 1 Raw Rare Metals = 0.66.. Rare Metals
--     9 Raw Rare Metals processed with 10 Hydrogen Chloride to 6 Enriched Rare Metals
--     5 Enriched Rare Metals to 5 Rare Metals
-- 3rd Tier: 1 Raw Rare Metals = 1 Rare Metals
--     9 Raw Rare Metals processed with 10 Hydrogen Chloride to 6 Enriched Rare Metals
--     24 Enriched Rare Metals processed with 1 Vulcanite Block to 36 Rare Metals

-- Create a Rare Metal-Vulcanite smelting recipe
local rare_metals_vulcanite = table.deepcopy(data.raw.recipe["se-molten-copper"])
rare_metals_vulcanite.name = "rare-metals-vulcanite"
rare_metals_vulcanite.ingredients = {
  {"enriched-rare-metals", 24},
  {"se-vulcanite-block", 1}
}
rare_metals_vulcanite.icons = data_util.sub_icons(data.raw.item["rare-metals"].icon,
                                                  data.raw.item[data_util.mod_prefix .. "vulcanite-block"].icon)
rare_metals_vulcanite.results = {{"rare-metals", 36}}
rare_metals_vulcanite.group = "resources"
rare_metals_vulcanite.subgroup = "rare-metals"
rare_metals_vulcanite.order = "a-d"
data.raw.recipe["rare-metals-vulcanite"] = rare_metals_vulcanite
table.insert(data.raw.technology["se-pyroflux-smelting"].effects, {type = "unlock-recipe", recipe = "rare-metals-vulcanite"})

-- Update K2s Rare Metal recipes to share the same subgroup
data.raw.item["raw-rare-metals"].subgroup = "rare-metals"
data.raw.item["raw-rare-metals"].order = "a"
data.raw.item["enriched-rare-metals"].subgroup = "rare-metals"
data.raw.item["enriched-rare-metals"].order = "b"
data.raw.item["rare-metals"].subgroup = "rare-metals"
data.raw.item["rare-metals"].order = "c"

data.raw.recipe["rare-metals"].subgroup = "rare-metals"
data.raw.recipe["rare-metals"].order = "a-a"
data.raw.recipe["enriched-rare-metals"].subgroup = "rare-metals"
data.raw.recipe["enriched-rare-metals"].order = "a-b"
data.raw.recipe["dirty-water-filtration-3"].subgroup = "rare-metals"
data.raw.recipe["dirty-water-filtration-3"].order = "a-c"
data.raw.recipe["rare-metals-2"].subgroup = "rare-metals"
data.raw.recipe["rare-metals-2"].order  = "a-d"

---- Imersite ----

-- K2
-- Raw Imersite -> Imersite Powder -> Imersite Crystal/Imersite Plate
-- 1 Raw Imersite Ore : 0.166.. Imersite Crystal
-- 1 Raw Imersite Ore : 0.33.. Imersite Plate

-- SE-K2
-- 6 Raw Imersite processed via the Pulveriser into 3 Crushed Imersite + 3 Sand (base K2 recipe, just renamed Imersite Powder)
-- 25 Crushed Imersite and 5 Sulfuric Acid (Heating) ->  50 Imersiumsulfide (Fluid)
-- 8 Imersiumsulfide + 15 Nitric Acid (Heating)-> 8 Fine Imersite Powder + 5 Nitrogen (Fine Imersite Powder replaces all current uses of Imersite Powder)

--  32 Fine Imersite Powder + 8 Rare Metals (Alloying) -> 4 Imersium Plate + 2 Sulfur
--  40 Imersiumsulfide + 8 Fine Imersite Powder + 6 Silicon (Crystalisation)->  6 Imersite Crystals + 3 Sulfur

-- 1 Raw Imersite Ore : 1 Fine Imersite Powder
-- 1 Raw Imersite Ore : 0.125 Imersite Crystal
-- 1 Raw Imersite Ore : 0.125 Imersite Plate
-- Vulc and Cryo are 1 Ore : 0.1 Block/Rod but as no guarenteed Imersite primary we are a little kinder on ratios?

-- Alter Imersite Powder localisation
data.raw.item["imersite-powder"].localised_name = {"item-name.se-kr-imersite-powder"}



-- Adjust Crushed Imersite recipe
data_util.replace_or_add_ingredient("imersite-powder", "raw-imersite", "raw-imersite", 6)

-- 25 Crushed Imersite + 5 Sulfuric Acid => 50 Imersium Sulfide
-- Productivity intentionally left disabled for this recipe
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-imersium-sulfide",
  category = "chemistry",
  subgroup = "imersite",
  energy_required = 15,
  ingredients = {
    { name = "imersite-powder", amount = 25},
    { type = "fluid", name = "sulfuric-acid", amount = 5}
  },
  results = {
    { type = "fluid", name = "se-kr-imersium-sulfide", amount = 50}
  },
  main_product = "se-kr-imersium-sulfide",
  always_show_made_in = true,
  enabled = false
})
table.insert(data.raw.technology["kr-quarry-minerals-extraction"].effects, {type = "unlock-recipe", recipe = "se-kr-imersium-sulfide"})

-- 16 Imersiumsulfide + 30 Nitric Acid (Heating)-> 16 Fine Imersite Powder + 10 Nitrogen
-- Productivity intentionally left disabled for this recipe
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-fine-imersite-powder",
  category = "smelting",
  subgroup = "imersite",
  energy_required = 10,
  ingredients = {
    { type = "fluid", name = "se-kr-imersium-sulfide", amount = 16},
    { type = "fluid", name = "nitric-acid", amount = 30}
  },
  results = {
    { name = "se-kr-fine-imersite-powder", amount = 16},
    { type = "fluid", name = "nitrogen", amount = 10}
  },
  main_product = "se-kr-fine-imersite-powder",
  always_show_made_in = true,
  enabled = false
})
table.insert(data.raw.technology["kr-quarry-minerals-extraction"].effects, {type = "unlock-recipe", recipe = "se-kr-fine-imersite-powder"})

-- Adjust Imersite Plate recipe
data_util.replace_or_add_ingredient("imersium-plate", "imersite-powder", "se-kr-fine-imersite-powder", 32)
data_util.replace_or_add_ingredient("imersium-plate", "rare-metals", "rare-metals", 8)
data_util.replace_or_add_result("imersium-plate", "imersium-plate", "imersium-plate", 4)
data_util.replace_or_add_result("imersium-plate", nil, "sulfur", 2)
data_util.recipe_set_energy_required("imersium-plate", 20)
data.raw.recipe["imersium-plate"].main_product = "imersium-plate"

-- Adjust Imersite Crystal recipe
data_util.replace_or_add_ingredient("imersite-crystal", "sulfuric-acid", "se-kr-imersium-sulfide", 40, true)
data_util.replace_or_add_ingredient("imersite-crystal", "imersite-powder", "se-kr-fine-imersite-powder", 8)
data_util.replace_or_add_ingredient("imersite-crystal", "nitric-acid", "silicon", 6)
data_util.replace_or_add_result("imersite-crystal", "imersite-crystal", "imersite-crystal", 6)
data_util.replace_or_add_result("imersite-crystal", nil, "sulfur", 3)
data.raw.recipe["imersite-crystal"].main_product = "imersite-crystal"

-- Update K2s Imersite recipes to share the same subgroup
data.raw.item["raw-imersite"].subgroup = "imersite"
data.raw.item["raw-imersite"].order = "a-a-b"
data.raw.item["imersite-powder"].subgroup = "imersite"
data.raw.item["imersite-powder"].order = "b"
data.raw.item["imersite-crystal"].group = "resources"
data.raw.item["imersite-crystal"].subgroup = "imersite"
data.raw.item["imersite-crystal"].order = "d"
data.raw.item["imersium-plate"].subgroup = "imersite"
data.raw.item["imersium-plate"].order = "e"

data.raw.recipe["imersite-powder"].order = "a-a"
data.raw.recipe["imersite-crystal"].group = "resources"
data.raw.recipe["imersite-crystal"].subgroup = "imersite"
data.raw.recipe["imersite-crystal"].order = "a-b"
data.raw.recipe["imersium-plate"].order = "a-d"

-- Replace Imersite Powder with Fine Imersite Powder in all other recipes
data_util.replace_or_add_ingredient("improved-pollution-filter", "imersite-powder", "se-kr-fine-imersite-powder", 1)
data_util.replace_or_add_ingredient("kr-creep-virus", "imersite-powder", "se-kr-fine-imersite-powder", 5)
data_util.replace_or_add_ingredient("kr-s-c-imersium-beam", "imersite-powder", "se-kr-fine-imersite-powder", 6)
data_util.replace_or_add_ingredient("kr-s-c-imersium-gear-wheel", "imersite-powder", "se-kr-fine-imersite-powder", 3)
data_util.replace_or_add_ingredient("advanced-fuel", "imersite-powder", "se-kr-fine-imersite-powder", 6)

---- Lithium ----

-- Update K2s Lithium recipes to share the same subgroup
data.raw.item["lithium-chloride"].subgroup = "lithium"
data.raw.item["lithium-chloride"].order = "a"
data.raw.item["lithium"].subgroup = "lithium"
data.raw.item["lithium"].order = "b"
data.raw.item["lithium-sulfur-battery"].group = "intermediate-products"
data.raw.item["lithium-sulfur-battery"].subgroup = "intermediate-product"

data.raw.recipe["lithium-chloride"].subgroup = "lithium"
data.raw.recipe["lithium-chloride"].order = "a-a"
data.raw.recipe["lithium"].subgroup = "lithium"
data.raw.recipe["lithium"].order = "a-b"

---- Stone ----

data.raw.recipe["se-glass-vulcanite"].results ={{"glass", 24}}

-- Create a Silicon-Vulcanite smelting recipe
local silicon_vulcanite = table.deepcopy(data.raw.recipe["se-molten-copper"])
silicon_vulcanite.name = "silicon-vulcanite"
silicon_vulcanite.ingredients = {
  {"quartz", 18},
  {"se-vulcanite-block", 1}
}
silicon_vulcanite.icons = data_util.sub_icons(data.raw.item["silicon"].icon,
                                              data.raw.item[data_util.mod_prefix .. "vulcanite-block"].icon)
silicon_vulcanite.results = {{"silicon", 18}}
silicon_vulcanite.group = "resources"
silicon_vulcanite.subgroup = "raw-material"
data.raw.recipe["silicon-vulcanite"] = silicon_vulcanite
table.insert(data.raw.technology["se-pyroflux-smelting"].effects, {type = "unlock-recipe", recipe = "silicon-vulcanite"})


-- Update K2s Stone recipes to share the same subgroup as SEs recipes
data.raw.item["quartz"].subgroup = "stone"
data.raw.item["quartz"].order = "a[quartz]"
data.raw.item["silicon"].subgroup = "stone"
data.raw.item["silicon"].order = "a[silicon]"

data.raw.recipe["silicon"].category = "kiln"
data.raw.recipe["silicon-vulcanite"].category = "kiln"
data.raw.recipe["silicon-vulcanite"].subgroup = "stone"
data.raw.recipe["silicon-vulcanite"].order = "a[silicon-vulcanite]"
data.raw.recipe["quartz"].subgroup = "stone"
data.raw.recipe["quartz"].order = "a[quartz]"

---- Additional changes ----

-- Add Enriched Ore as a prerequisite to vulcanie processing
table.insert(data.raw.technology["se-processing-vulcanite"].prerequisites, "kr-enriched-ores")

-- Switch Coke recipes over to the Kiln recipe group
data.raw.recipe["coke"].category = "kiln"

-- Allow productivity on created recipes
data_util.allow_productivity({
  "rare-metals-vulcanite",
  "silicon-vulcanite",
})
