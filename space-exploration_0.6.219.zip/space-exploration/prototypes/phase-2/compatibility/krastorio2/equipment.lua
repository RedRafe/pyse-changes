local data_util = require("data_util")

-- Radars
if data.raw.technology["kr-radar"] then
  data_util.tech_add_ingredients("kr-radar",{"basic-tech-card"})
  data_util.tech_remove_prerequisites("kr-radar", {"chemical-science-pack"})
  data_util.tech_remove_ingredients("kr-radar", {"chemical-science-pack"})
end

data_util.replace_or_add_ingredient("radar","iron-plate","steel-plate",15)