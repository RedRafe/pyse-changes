local data_util = require("data_util")

-- Unifying Science pack ordering.
data.raw.tool["automation-science-pack"].order = "b02[automation-tech-card]"
data.raw.tool["logistic-science-pack"].order = "b03[logistic-tech-card]"
data.raw.tool["military-science-pack"].order = "b04[military-tech-card]"
data.raw.tool["chemical-science-pack"].order = "b05[chemical-tech-card]"
data.raw.tool["se-rocket-science-pack"].order = "c[rocket-science-pack]"
data.raw.tool["space-science-pack"].order = "d[space-sciecne-pack]"
data.raw.tool["production-science-pack"].order = "e[production-science-pack]"
data.raw.tool["utility-science-pack"].order = "f[production-science-pack]"
data.raw.tool["kr-optimization-tech-card"].order  = "g[optimization-tech-card-1]-a"
data.raw.tool["advanced-tech-card"].order = "g[optimization-tech-card-2]-b"
data.raw.tool["singularity-tech-card"].order = "g[optimization-tech-card-3]-c"

-- Remove the K2 Science pack categories
data.raw["recipe-category"]["t2-tech-cards"] = nil
data.raw["recipe-category"]["t3-tech-cards"] = nil


---- Changing science packs icons to Krastorio 2 design for on planet techs
-- Automation science pack
krastorio.icons.setItemIcon("automation-science-pack", kr_cards_icons_path .. "automation-tech-card.png")
krastorio.icons.setTechnologyIcon("automation-science-pack", kr_technologies_icons_path .. "automation-tech-card.png", 256, 4)

-- Logistic science pack
krastorio.icons.setItemIcon("logistic-science-pack", kr_cards_icons_path .. "logistic-tech-card.png")
krastorio.icons.setTechnologyIcon("logistic-science-pack", kr_technologies_icons_path .. "logistic-tech-card.png", 256, 4)

-- Military science pack
krastorio.icons.setItemIcon("military-science-pack", kr_cards_icons_path .. "military-tech-card.png")
krastorio.icons.setTechnologyIcon("military-science-pack", kr_technologies_icons_path .. "military-tech-card.png", 256, 4)

-- Chemical science pack
krastorio.icons.setItemIcon("chemical-science-pack", kr_cards_icons_path .. "chemical-tech-card.png")
krastorio.icons.setTechnologyIcon("chemical-science-pack", kr_technologies_icons_path .. "chemical-tech-card.png", 256, 4)

-- -- Space science pack
-- krastorio.icons.setItemIcon("kr-optimization-tech-card", kr_cards_icons_path .. "optimization-tech-card.png")
-- data.raw.tool["kr-optimization-tech-card"].order = "b09[optimization-tech-card]"
-- krastorio.icons.setTechnologyIcon("kr-optimization-tech-card", kr_technologies_icons_path .. "optimization-tech-card.png", 256, 4)
-- data.raw.recipe["kr-optimization-tech-card"].category = "t2-tech-cards"

-- Rocket science pack
-- Since K2 doesn't have an icon for this specifically, we will use one of the existing but unused K2 icons instead.
krastorio.icons.setItemIcon("se-rocket-science-pack", "__Krastorio2Assets__/icons/cards/utility-tech-card.png")
krastorio.icons.setTechnologyIcon("se-rocket-science-pack", "__Krastorio2Assets__/technologies/utility-tech-card.png", 256, 4)
krastorio.icons.setRecipeIcon("se-rocket-science-pack", "__Krastorio2Assets__/icons/cards/utility-tech-card.png")
data.raw.tool["se-rocket-science-pack"].localised_name = {"item-name.se-kr-rocket-tech-card"}
data.raw.technology["se-rocket-science-pack"].localised_name = {"technology-name.se-kr-rocket-tech-card"}

-- Add Blank Tech Card from K2 tech cards
data_util.replace_or_add_ingredient("se-rocket-science-pack", nil, "blank-tech-card", 8)

---- Production Science Pack
-- Change graphics back to SEs
local production_pack = data.raw.tool["production-science-pack"]
production_pack.localised_name = {"item-name.production-science-pack"}
production_pack.icon = nil
production_pack.icon_size = nil
production_pack.icons = {
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/deep-2.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-2.png", icon_size = 64, tint = {r=1, g=0, b=0}}
}
production_pack.pictures = nil
data.raw.technology["production-science-pack"].localised_name = {"technology-name.production-science-pack"}

-- Reconcile conflicting recipes
data.raw.recipe["production-science-pack"].category = "space-manufacturing"
data.raw.recipe["production-science-pack"].subgroup = "science-pack"
data.raw.recipe["production-science-pack"].ingredients = {
  {name = "productivity-module", amount = 1},
  {name = "uranium-238", amount = 2},
  {name = "se-vulcanite-block", amount = 4},
  {name = "se-machine-learning-data", amount = 1},
  {name = "se-iron-ingot", amount = 8},
  {type = "fluid", name = "se-plasma-stream", amount = 100},
}

---- Utility Science Pack
-- Change graphics back to SEs
local utility_pack = data.raw.tool["utility-science-pack"]
utility_pack.localised_name = {"item-name.utility-science-pack"}
utility_pack.icon = nil
utility_pack.icon_size = nil
utility_pack.icons = {
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/deep-2.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-2.png", icon_size = 64, tint = {r=0, g=1, b=0.8}}
}
utility_pack.pictures = nil
data.raw.technology["utility-science-pack"].localised_name = {"technology-name.utility-science-pack"}

-- Reconcile conflicting recipes
data.raw.recipe["utility-science-pack"].category = "space-manufacturing"
data.raw.recipe["utility-science-pack"].subgroup = "science-pack"
data.raw.recipe["utility-science-pack"].ingredients = {
  {name = "se-space-transport-belt", amount = 1},
  {name = "effectivity-module", amount = 1},
  {name = "processing-unit", amount = 1},
  {name = "se-cryonite-rod", amount = 6},
  {name = "se-machine-learning-data", amount = 4},
  {type = "fluid", name = "se-space-coolant-warm", amount = 20},
}

---- K2 Optimization Tech Card
-- Move Quarry Mineral Extraction (Imersite Mining) to same stage as other SE space materials and act as prereqs for Optimization
data_util.tech_remove_prerequisites("kr-quarry-minerals-extraction",{"production-science-pack"})
data_util.tech_remove_ingredients("kr-quarry-minerals-extraction",{"production-science-pack"})
data_util.tech_add_prerequisites("kr-quarry-minerals-extraction", {"space-science-pack"})
data_util.tech_add_ingredients("kr-quarry-minerals-extraction", {"space-science-pack"})

data_util.tech_remove_prerequisites("kr-imersium-processing", {"kr-matter-tech-card"})
data_util.tech_remove_ingredients("kr-imersium-processing", {"production-science-pack","utility-science-pack","matter-tech-card"})
data_util.tech_add_prerequisites("kr-imersium-processing", {"kr-quarry-minerals-extraction"})
data_util.tech_add_ingredients("kr-imersium-processing", {"automation-science-pack","logistic-science-pack","chemical-science-pack","space-science-pack"})

if data.raw.item["space-research-data"] and not data.raw.recipe["space-research-data"] then
  data:extend({
    {
        type = "recipe",
        name = "space-research-data",
        enabled = false,
        energy_required = 1,
        ingredients = {
          { name = "se-heat-shielding", amount = 2},
          { name = "speed-module", amount = 1},
          { name = "imersite-crystal", amount = 2},
          { name = "imersium-plate", amount = 3},
          { name = "se-machine-learning-data", amount = 3},
          { type = "fluid", name = "lubricant", amount = 100}
        },
        results = {
          {"space-research-data", 5},
        },
        main_product = "space-research-data",
        requester_paste_multiplier = 1,
        subgroup = "science-pack",
        category = "space-manufacturing",
        always_show_made_in = true
    }
  })
  data_util.recipe_require_tech("space-research-data", "kr-optimization-tech-card")
end

-- Remove rocket launch product from Optimization Tech Card
data.raw.tool["kr-optimization-tech-card"].rocket_launch_product = nil

-- Update Optimization Tech Card to only be made in space
data.raw.recipe["kr-optimization-tech-card"].category = "space-manufacturing"
data.raw.recipe["kr-optimization-tech-card"].always_show_made_in = true
if data.raw.recipe["kr-optimization-tech-card"].normal then
  data.raw.recipe["kr-optimization-tech-card"].normal.always_show_made_in = true
end
if data.raw.recipe["kr-optimization-tech-card"].expensive then
  data.raw.recipe["kr-optimization-tech-card"].expensive.always_show_made_in = true
end

data_util.tech_remove_prerequisites("kr-optimization-tech-card", {"se-processing-cryonite","uranium-processing","electric-energy-accumulators","production-science-pack","se-space-science-lab","kr-singularity-lab"})
data_util.tech_remove_ingredients("kr-optimization-tech-card", {"production-science-pack"})
data_util.tech_add_prerequisites("kr-optimization-tech-card", {"se-space-supercomputer-1","kr-imersium-processing"})
data_util.tech_add_ingredients("kr-optimization-tech-card", {"space-science-pack"})


-- Bring the Advanced Tech Card to after Space Science 3s
data_util.tech_add_prerequisites("kr-advanced-tech-card",{"se-energy-science-pack-3","se-material-science-pack-3","se-biological-science-pack-3","se-astronomic-science-pack-3"})
data_util.tech_add_ingredients("kr-advanced-tech-card",{"kr-optimization-tech-card","se-energy-science-pack-3","se-material-science-pack-3","se-biological-science-pack-3","se-astronomic-science-pack-3"})
data_util.tech_remove_ingredients("kr-advanced-tech-card",{"matter-tech-card"})

-- Adjust Advanced Tech Card cost
data_util.replace_or_add_ingredient("advanced-tech-card","electric-engine-unit","se-bioscrubber",5)
data_util.replace_or_add_ingredient("advanced-tech-card",nil,"se-pylon",2)
data_util.replace_or_add_ingredient("advanced-tech-card",nil,"se-space-platform-plating",1)

-- Remove Advanced Tech Card tech as Prerequisite for Singularity Tech Card
data_util.tech_remove_prerequisites("kr-singularity-tech-card",{"kr-advanced-tech-card"})

---- Matter Science Pack
-- Matter Science Pack Tint
local matter_pack_tint = {r = 255, g = 51, b = 151}
-- Science Groups
data:extend({
  {
    type = "item-subgroup",
    name = "data-catalogue-matter",
    group = "science",
    order = "q-d"
  },
  {
    type = "item-subgroup",
    name = "data-matter",
    group = "science",
    order = "q-e"
  },
  {
    type = "item-subgroup",
    name = "matter-science-pack",
    group = "science",
    order = "q-f"
  }
})

-- Data Cards Items
data.raw.item["matter-research-data"].subgroup = "data-matter"
data.raw.item["matter-research-data"].icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-analysis.png"
data.raw.item["matter-research-data"].stack_size = 50
local matter_synthesis_data = {
  type = "item",
  name = "se-kr-matter-synthesis-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-synthesis.png",
  icon_size = 64,
  order = "a-b",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_synthesis_data})
local matter_liberation_data = {
  type = "item",
  name = "se-kr-matter-liberation-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-liberation.png",
  icon_size = 64,
  order = "a-b",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_liberation_data})
local matter_containment_data = {
  type = "item",
  name = "se-kr-matter-containment-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-containment.png",
  icon_size = 64,
  order = "a-b",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_containment_data})

local matter_manipulation_data = {
  type = "item",
  name = "se-kr-matter-manipulation-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-manipulation.png",
  icon_size = 64,
  order = "b-c",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_manipulation_data})
local matter_recombinaion_data = {
  type = "item",
  name = "se-kr-matter-recombination-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-recombination.png",
  icon_size = 64,
  order = "b-c",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_recombinaion_data})
local matter_stabilization_data = {
  type = "item",
  name = "se-kr-matter-stabilization-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-stabilization.png",
  icon_size = 64,
  order = "b-c",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_stabilization_data})
local matter_utilization_data = {
  type = "item",
  name = "se-kr-matter-utilization-data",
  icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-utilization.png",
  icon_size = 64,
  order = "b-c",
  subgroup = "data-matter",
  stack_size = 50,
}
data:extend({matter_utilization_data})

-- Data Card Recipes
-- Matter Analysis
local matter_analysis = data.raw.recipe["matter-research-data"]
matter_analysis.icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-analysis.png"
matter_analysis.icon_size = 64
matter_analysis.ingredients = {
  {name = "se-material-testing-pack", amount = 1},
  {name = "se-quantum-phenomenon-data", amount = 1},
  {name = "se-quark-data", amount = 1},
  {type = "fluid", name = "se-particle-stream", amount = 50},
}
matter_analysis.result = nil
matter_analysis.results = {
  {name = "matter-research-data", amount = 1},
  {name = "se-junk-data", amount_min = 1, amount_max = 1, probability = 0.70},
  {name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.30},
  {type = "fluid", name = "se-particle-stream", amount = 35},
}
matter_analysis.main_product = "matter-research-data"
matter_analysis.category = "space-materialisation"
matter_analysis.subgroup = "data-matter"

-- Matter Synthesis
local matter_synthesis = data.raw.recipe["se-matter-fusion-dirty"]
matter_synthesis.icon = "__space-exploration-graphics__/graphics/compatability/icons/matter-synthesis.png"
matter_synthesis.icon_size = 64
matter_synthesis.icons = nil
matter_synthesis.main_product = "se-kr-matter-synthesis-data"
matter_synthesis.subgroup = "data-matter"
matter_synthesis.ingredients = {
  { name = "se-quark-data", amount = 1},
  { type = "fluid", name = "se-particle-stream", amount = 50},
  { type = "fluid", name = "se-space-coolant-supercooled", amount = 25}
}
matter_synthesis.results = {
  { name = "se-contaminated-scrap", amount = 15},
  { name = "se-kr-matter-synthesis-data", amount_min = 1, amount_max = 1, probability = 0.90},
  { name = "se-junk-data", amount_min = 1, amount_max = 1, probability = 0.10},
  { type = "fluid", name = "se-space-coolant-hot", amount = 25}
}
matter_synthesis.energy_required = 10

-- Matter Liberation
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-liberation-data",
  category = "space-materialisation",
  subgroup = "data-matter",
  ingredients = {
    { name = "se-radiation-data", amount = 1},
    { name = "se-hot-thermodynamics-data", amount = 1},
    { name = "se-material-testing-pack", amount = 5},
    { type = "fluid", name = "se-particle-stream", amount = 100}
  },
  results = {
    { name = "se-kr-matter-liberation-data", amount = 1},
    { name = "se-junk-data", amount_min = 1, amount_max = 1, probability = 0.80},
    { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.20},
    { name = "se-contaminated-scrap", amount = 15},
    { type = "fluid", name = "se-particle-stream", amount = 110}
  },
  main_product = "se-kr-matter-liberation-data",
  always_show_made_in = true,
})

-- Matter Containment
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-containment-data",
  category = "space-materialisation",
  subgroup = "data-matter",
  ingredients = {
    { name = "se-forcefield-data", amount = 1},
    { name = "se-pressure-containment-data", amount = 1},
    { name = "se-magnetic-canister", amount = 5},
    { type = "fluid", name = "se-particle-stream", amount = 100}
  },
  results = {
    { name = "se-kr-matter-containment-data", amount_min = 2, amount_max = 2, probability = 0.70},
    { name = "se-junk-data", amount_min = 2, amount_max = 2, probability = 0.30},
    { name = "se-scrap", amount = 15},
    { name = "se-contaminated-scrap", amount = 10}
  },
  main_product = "se-kr-matter-containment-data",
  always_show_made_in = true,
})

-- Matter Manipulation
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-manipulation-data",
  group = "science",
  category = "basic-matter-conversion",
  subgroup = "data-matter",
  ingredients = {
    { name = "se-forcefield-data", amount = 1},
    { name = "se-hot-thermodynamics-data", amount = 1},
    { type = "fluid", name = "matter", amount = 50},
  },
  results = {
    { name = "se-kr-matter-manipulation-data", amount = 2},
    { name = "se-scrap", amount = 10},
    { type = "fluid", name = "se-particle-stream", amount = 40},
    { type = "fluid", name = "matter", amount = 10},
  },
  main_product = "se-kr-matter-manipulation-data",
  always_show_made_in = true,
})

-- Matter Recombination
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-recombination-data",
  group = "science",
  category = "basic-matter-conversion",
  subgroup = "data-matter",
  ingredients = {
    { name = "ai-core", amount = 1},
    { name = "se-boson-data", amount = 1},
    { name = "se-fusion-test-data", amount = 1},
    { type = "fluid", name = "matter", amount = 50},
  },
  results = {
    { name = "se-kr-matter-recombination-data", amount = 1},
    { name = "se-junk-data", amount_min = 1, amount_max = 1, probability = 0.80},
    { name = "se-broken-data", amount_min = 1, amount_max = 1, probability = 0.20},
    { name = "ai-core", amount_min = 1, amount_max = 1, probability = 0.75},
    { name = "se-scrap", amount = 15},
  },
  main_product = "se-kr-matter-recombination-data",
  allow_as_intermediate = false,
})

-- Matter Stabilization
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-stabilization-data",
  group = "science",
  category = "basic-matter-conversion",
  subgroup = "data-matter",
  ingredients = {
    { name = "ai-core", amount = 1},
    { name = "se-kr-matter-containment-data", amount = 1},
    { name = "se-experimental-alloys-data", amount = 1},
    { type = "fluid", name = "matter", amount = 50},
  },
  results = {
    { name = "se-kr-matter-stabilization-data", amount = 2},
    { name = "ai-core", amount_min = 1, amount_max = 1, probability = 0.80},
    { type = "fluid", name = "matter", amount = 45},
  },
  main_product = "se-kr-matter-stabilization-data",
  allow_as_intermediate = false,
})

-- Matter Utilization
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-utilization-data",
  group = "science",
  category = "basic-matter-conversion",
  subgroup = "data-matter",
  ingredients = {
    { name = "ai-core", amount = 1},
    { name = "se-magnetic-canister", amount = 5},
    { name = "se-kr-matter-containment-data", amount = 1},
    { type = "fluid", name = "matter", amount = 50},
  },
  results = {
    { name = "se-kr-matter-utilization-data", amount = 1},
    { name = "ai-core", amount = 1},
    { name = "se-magnetic-canister", amount_min = 1, amount_max = 4},
    { type = "fluid", name = "matter", amount = 35},
  },
  main_product = "se-kr-matter-utilization-data",
  allow_as_intermediate = false,
})

-- Catalogue items
local matter_catalogue = {
  type = "item",
  name = "se-kr-matter-catalogue-1",
  icons = {
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-1.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-1.png", icon_size = 64, tint = matter_pack_tint},
  },
  order = "a-b",
  subgroup = "data-catalogue-matter",
  stack_size = 50,
  pictures = {
    {
      layers = {
        {
          filename = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-1.png",
          scale = 0.25,
          size = 64,
        },
        {
          filename = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-1.png",
          scale = 0.25,
          size = 64,
          draw_as_glow = true,
          tint = matter_pack_tint
        }
      }
    }
  }
}
data:extend({matter_catalogue})

local matter_catalogue_2 = {
  type = "item",
  name = "se-kr-matter-catalogue-2",
  icons = {
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-2.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-2.png", icon_size = 64, tint = matter_pack_tint},
  },
  order = "a-b",
  subgroup = "data-catalogue-matter",
  stack_size = 50,
  pictures = {
    {
      layers = {
        {
          filename = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-2.png",
          scale = 0.25,
          size = 64,
        },
        {
          filename = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-2.png",
          scale = 0.25,
          size = 64,
          draw_as_glow = true,
          tint = matter_pack_tint
        }
      }
    }
  }
}
data:extend({matter_catalogue_2})

-- Catalogue recipes
data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-catalogue-1",
  ingredients = {
    { name = "matter-research-data", amount = 1 },
    { name = "se-kr-matter-synthesis-data", amount = 1},
    { name = "se-kr-matter-liberation-data", amount = 1},
    { name = "se-kr-matter-containment-data", amount = 1},
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 10},
  },
  results = {
    { name = "se-kr-matter-catalogue-1", amount = 1 },
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 10},
  },
  energy_required = 50,
  main_product = "se-kr-matter-catalogue-1",
  subgroup = "data-catalogue-matter",
  icons = {
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-1.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-1.png", icon_size = 64, tint = matter_pack_tint}
  },
  category = "catalogue-creation-1",
  always_show_made_in = true,
})

data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-catalogue-2",
  ingredients = {
    { name = "se-kr-matter-manipulation-data", amount = 1},
    { name = "se-kr-matter-recombination-data", amount = 1},
    { name = "se-kr-matter-stabilization-data", amount = 1},
    { name = "se-kr-matter-utilization-data", amount = 1},
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-supercooled", amount = 10},
  },
  results = {
    { name = "se-kr-matter-catalogue-2", amount = 1 },
    { type = "fluid", name = data_util.mod_prefix .. "space-coolant-hot", amount = 10},
  },
  energy_required = 60,
  main_product = "se-kr-matter-catalogue-2",
  subgroup = "data-catalogue-matter",
  icons = {
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/base-catalogue-2.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-catalogue-2.png", icon_size = 64, tint = matter_pack_tint}
  },
  category = "catalogue-creation-2",
  always_show_made_in = true,
})

--- Catalogue techs
local matter_catalogue_tech = {
  type = "technology",
  name = "se-kr-space-catalogue-matter-1",
  effects = {
    { type = "unlock-recipe", recipe = "se-kr-matter-catalogue-1" }
  },
  icons = {
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/base-catalogue-1.png", icon_size = 128},
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/mask-catalogue-1.png", icon_size = 128, tint = matter_pack_tint}
  },
  order = "e-g",
  prerequisites = {
    "se-space-material-fabricator"
  },
  unit = {
    count = 100,
    time = 60,
    ingredients = {
      {"automation-science-pack", 1},
      {"logistic-science-pack", 1},
      {"chemical-science-pack", 1},
      {"se-rocket-science-pack", 1},
      {"space-science-pack", 1},
      {"production-science-pack", 1},
      {"utility-science-pack", 1},
      {"se-astronomic-science-pack-2", 1},
      {"se-energy-science-pack-3", 1},
      {"se-material-science-pack-2", 1},
    }
  },
}
data:extend({matter_catalogue_tech})
data_util.recipe_require_tech("matter-research-data", "se-kr-space-catalogue-matter-1")
data_util.recipe_require_tech("se-matter-fusion-dirty", "se-kr-space-catalogue-matter-1")
data_util.recipe_require_tech("se-kr-matter-liberation-data", "se-kr-space-catalogue-matter-1")
data_util.recipe_require_tech("se-kr-matter-containment-data", "se-kr-space-catalogue-matter-1")


local matter_catalogue_2_tech = {
  type = "technology",
  name = "se-kr-space-catalogue-matter-2",
  effects = {
    { type = "unlock-recipe", recipe = "se-kr-matter-catalogue-2" },
    { type = "unlock-recipe", recipe = "se-kr-matter-manipulation-data"},
    { type = "unlock-recipe", recipe = "se-kr-matter-recombination-data"},
    { type = "unlock-recipe", recipe = "se-kr-matter-stabilization-data"},
    { type = "unlock-recipe", recipe = "se-kr-matter-utilization-data"},
  },
  icons = {
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/base-catalogue-2.png", icon_size = 128},
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/mask-catalogue-2.png", icon_size = 128, tint = matter_pack_tint}
  },
  order = "e-g",
  prerequisites = {
  },
  unit = {
    count = 100,
    time = 60,
    ingredients = {
      {"se-rocket-science-pack", 1},
      {"space-science-pack", 1},
      {"matter-tech-card", 1},
      {"se-deep-space-science-pack-1", 1},
    }
  },
}
data:extend({matter_catalogue_2_tech})

-- Science Pack Items
local matter_science_pack_1 = data.raw.tool["matter-tech-card"]
matter_science_pack_1.subgroup = "matter-science-pack"
matter_science_pack_1.order = "l[matter-science-pack-1]-a"
matter_science_pack_1.icon = nil
matter_science_pack_1.icon_size = nil
matter_science_pack_1.icons = {
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/deep-2.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-2.png", icon_size = 64, tint = matter_pack_tint}
}
matter_science_pack_1.pictures = {
  {
    layers = {
      {
        filename = "__space-exploration-graphics__/graphics/icons/catalogue/deep-2.png",
        scale = 0.25,
        size = 64
      },
      {
        filename = "__space-exploration-graphics__/graphics/icons/catalogue/mask-2.png",
        scale = 0.25,
        size = 64,
        draw_as_glow = true,
        tint = matter_pack_tint
      }
    }
  }
}

local matter_science_pack_2 = table.deepcopy(data.raw.tool["matter-tech-card"])
matter_science_pack_2.name = "se-kr-matter-science-pack-2"
matter_science_pack_2.order = "l[matter-science-pack-2]-b"
matter_science_pack_2.icons = {
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/deep-3.png", icon_size = 64},
  {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-3.png", icon_size = 64, tint = matter_pack_tint}
}
matter_science_pack_2.pictures = {
  {
    layers = {
      {
        filename = "__space-exploration-graphics__/graphics/icons/catalogue/deep-3.png",
        scale = 0.25,
        size = 64
      },
      {
        filename = "__space-exploration-graphics__/graphics/icons/catalogue/mask-3.png",
        scale = 0.25,
        size = 64,
        draw_as_glow = true,
        tint = matter_pack_tint
      }
    }
  }
}
data:extend({matter_science_pack_2})

-- Science Pack Recipes
local matter_tech_card_recipe = data.raw.recipe["matter-tech-card"]
matter_tech_card_recipe.category = "science-pack-creation-1"
matter_tech_card_recipe.subgroup = "matter-science-pack"
matter_tech_card_recipe.ingredients = {
  {name = "se-scrap", amount = 10},
  {name = "se-significant-data", amount = 1},
  {name = "se-kr-matter-catalogue-1", amount = 1},
  {type = "fluid", name = "se-particle-stream", amount = 5},
  {type = "fluid", name = "se-space-coolant-supercooled", amount = 50}
}
matter_tech_card_recipe.results = {
  {name = "matter-tech-card", amount = 2},
  {name = "se-junk-data", amount = 4},
  {name = "se-broken-data", amount = 1},
  {type = "fluid", name = "se-space-coolant-hot", amount = 50}
}
matter_tech_card_recipe.energy_required = 10
matter_tech_card_recipe.main_product = "matter-tech-card"
matter_tech_card_recipe.always_show_made_in = true

data_util.make_recipe({
  type = "recipe",
  name = "se-kr-matter-science-pack-2",
  category = "science-pack-creation-2",
  subgroup = "matter-science-pack",
  ingredients = {
    { name = "se-scrap", amount = 10}, -- needs changed?
    { name = "se-significant-data", amount = 1},
    { name = "se-kr-matter-catalogue-2", amount = 1},
    { name = "matter-tech-card", amount = 2},
    { type = "fluid", name = "matter", amount = 50 },
    { type = "fluid", name = "se-space-coolant-supercooled", amount = 100},
  },
  results = {
    { name = "se-kr-matter-science-pack-2", amount = 4},
    { name = "se-junk-data", amount = 4},
    { name = "se-broken-data", amount = 1},
    { type = "fluid", name = "se-space-coolant-hot", amount = 100},
  },
  energy_required = 20,
  main_product = "se-kr-matter-science-pack-2",
  icons = {
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/deep-3.png", icon_size = 64},
    {icon = "__space-exploration-graphics__/graphics/icons/catalogue/mask-3.png", icon_size = 64, tint = matter_pack_tint}
  },
  always_show_made_in = true,
})

-- Science Pack Techs
-- Bring the Matter Tech Card to directly after the Matter Fabricator Tech
data_util.tech_remove_prerequisites("kr-matter-tech-card", {"kr-quantum-computer","se-space-material-fabricator","se-naquium-tessaract","kr-singularity-lab","se-deep-space-science-pack-2"})
data_util.tech_remove_ingredients("kr-matter-tech-card",{"se-deep-space-science-pack-2"})
data_util.tech_add_prerequisites("kr-matter-tech-card", {"se-kr-space-catalogue-matter-1"})
data_util.tech_add_ingredients("kr-matter-tech-card",{"se-energy-science-pack-3","se-material-science-pack-2","se-astronomic-science-pack-2"})
data.raw.technology["kr-matter-tech-card"].icon = nil
data.raw.technology["kr-matter-tech-card"].icon_size = nil
data.raw.technology["kr-matter-tech-card"].icons = {
  {icon = "__space-exploration-graphics__/graphics/technology/catalogue/deep-2.png", icon_size = 128},
  {icon = "__space-exploration-graphics__/graphics/technology/catalogue/mask-2.png", icon_size = 128, tint = matter_pack_tint}
}


local matter_science_pack_2_tech = {
  type = "technology",
  name = "se-kr-matter-science-pack-2",
  effects = {
    { type = "unlock-recipe", recipe = "se-kr-matter-science-pack-2" }
  },
  icons = {
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/deep-3.png", icon_size = 128},
    {icon = "__space-exploration-graphics__/graphics/technology/catalogue/mask-3.png", icon_size = 128, tint = matter_pack_tint}
  },
  order = "e-g",
  prerequisites = {
    "se-kr-space-catalogue-matter-2"
  },
  unit = {
    count = 2000,
    time = 60,
    ingredients = {
      {"se-rocket-science-pack", 1},
      {"space-science-pack", 1},
      {"matter-tech-card", 1}
    }
  }
}
data:extend({matter_science_pack_2_tech})

---- Add Optimisation Tech Card to the simulation techs.
data_util.tech_add_prerequisites("se-space-simulation-sb", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-sb", {"kr-optimization-tech-card"})
data_util.tech_add_prerequisites("se-space-simulation-bm", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-bm", {"kr-optimization-tech-card"})
data_util.tech_add_prerequisites("se-space-simulation-ab", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-ab", {"kr-optimization-tech-card"})
data_util.tech_add_prerequisites("se-space-simulation-sm", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-sm", {"kr-optimization-tech-card"})
data_util.tech_add_prerequisites("se-space-simulation-as", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-as", {"kr-optimization-tech-card"})
data_util.tech_add_prerequisites("se-space-simulation-am", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-am", {"kr-optimization-tech-card"})

data_util.tech_add_ingredients("se-space-simulation-sbm", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-asb", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-abm", {"kr-optimization-tech-card"})
data_util.tech_add_ingredients("se-space-simulation-asm", {"kr-optimization-tech-card"})

data_util.tech_add_ingredients("se-space-simulation-asbm", {"kr-optimization-tech-card"})

-- Move the Advanced Tech Card to the Research Server
data.raw.recipe["advanced-tech-card"].category = "science-pack-creation-1"

-- Move the Research Server technology
data_util.tech_add_prerequisites("kr-research-server",{"se-space-supercomputer-1"})
data_util.tech_add_ingredients("kr-research-server",{"se-rocket-science-pack","space-science-pack"})
data_util.tech_remove_prerequisites("kr-research-server",{"chemical-science-pack"})

-- Add Research Server as Prerequisite to Catalogue techs
data_util.tech_add_prerequisites("se-space-catalogue-astronomic-1",{"kr-research-server"})
data_util.tech_add_prerequisites("se-space-catalogue-biological-1",{"kr-research-server"})
data_util.tech_add_prerequisites("se-space-catalogue-material-1",{"kr-research-server"})
data_util.tech_add_prerequisites("se-space-catalogue-energy-1",{"kr-research-server"})

-- Move the Advanced Research Server technology
data_util.tech_add_prerequisites("kr-quantum-computer",{"se-space-supercomputer-2","se-material-science-pack-3"})
data_util.tech_add_ingredients("kr-quantum-computer",{"se-biological-science-pack-3","se-energy-science-pack-3","se-material-science-pack-3"})