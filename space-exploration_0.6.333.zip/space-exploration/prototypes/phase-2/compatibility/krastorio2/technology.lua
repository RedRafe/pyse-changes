local data_util = require("data_util")

data_util.tech_remove_prerequisites("physical-projectile-damage-16",{"se-naquium-processor"})
data_util.tech_add_prerequisites("physical-projectile-damage-16",{"se-deep-space-science-pack-4"})
data_util.tech_remove_prerequisites("physical-projectile-damage-18",{"se-deep-space-science-pack-4"})


-- Substation Mk2
-- Tell K2 to leave this alone
data.raw.technology["electric-energy-distribution-3"].check_science_packs_incompatibilities = false
-- Make Changes
data_util.tech_remove_prerequisites("electric-energy-distribution-3", {"kr-advanced-tech-card"})
data_util.tech_remove_ingredients("electric-energy-distribution-3", {"advanced-tech-card"})
data_util.tech_add_prerequisites("electric-energy-distribution-3", {"kr-optimization-tech-card","se-holmium-cable"})
data_util.tech_add_ingredients("electric-energy-distribution-3", {"automation-science-pack","logistic-science-pack","chemical-science-pack","kr-optimization-tech-card","se-energy-science-pack-1"})
data_util.replace_or_add_ingredient("kr-substation-mk2",nil,"se-holmium-cable", 4)