### ** Maintenance rules **

# Updating to newer SE release

1. Download the new SE release from the mod portal
2. Make sure to be on branch `MAIN`
3. Paste all the files to the current folder
4. Commit changes to `v0.6.1xx`
7. Switch to `pyse-changes` branch
8. run `git merge main` and resolve all merge conflicts accepting the incoming changes
9. Commit the merge with `v0.6.2xx`
