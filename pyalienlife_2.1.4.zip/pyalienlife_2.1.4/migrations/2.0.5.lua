if global.caravans and global.caravans.outpost_buildings then
    global.caravans = nil
end