if global.vatbrains and global.vatbrains.brains then
	global.vatbrains = global.vatbrains.brains
end