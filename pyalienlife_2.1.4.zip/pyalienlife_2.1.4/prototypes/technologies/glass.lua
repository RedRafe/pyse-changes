TECHNOLOGY {
    type = "technology",
    name = "glass",
    icon = "__pyalienlifegraphics2__/graphics/technology/glass.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 20,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}

