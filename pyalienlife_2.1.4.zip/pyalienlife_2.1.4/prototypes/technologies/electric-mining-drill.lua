TECHNOLOGY {
    type = "technology",
    name = "electric-mining-drill",
    icon = "__pyalienlifegraphics2__/graphics/technology/electric-mining-drill.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 100,
        ingredients = {
            {"automation-science-pack", 1},
            {"py-science-pack-1", 1},
        },
        time = 30
    }
}

