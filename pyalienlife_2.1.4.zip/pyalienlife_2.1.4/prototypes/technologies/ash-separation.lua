TECHNOLOGY {
    type = "technology",
    name = "ash-separation",
    icon = "__pyalienlifegraphics2__/graphics/technology/ash-separation.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 50,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}
