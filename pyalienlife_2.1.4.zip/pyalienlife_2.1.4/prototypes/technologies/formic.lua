TECHNOLOGY {
    type = "technology",
    name = "formic",
    icon = "__pyalienlifegraphics__/graphics/technology/formic.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"vrauks"},
    effects = {},
    unit = {
        count = 150,
        ingredients = {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1},
            -- {'py-science-pack-3', 1},
        },
        time = 50
    }
}
