TECHNOLOGY {
    type = "technology",
    name = "soil-washing",
    icon = "__pyalienlifegraphics2__/graphics/technology/washing-soil.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 50,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}

