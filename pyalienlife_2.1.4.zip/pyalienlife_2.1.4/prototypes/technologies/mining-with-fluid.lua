TECHNOLOGY {
    type = "technology",
    name = "mining-with-fluid",
    icon = "__pyalienlifegraphics2__/graphics/technology/mining-with-fluid.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 20,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}

