TECHNOLOGY {
    type = "technology",
    name = "basic-substrate",
    icon = "__pyalienlifegraphics2__/graphics/technology/basic-substrate.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 50,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}

