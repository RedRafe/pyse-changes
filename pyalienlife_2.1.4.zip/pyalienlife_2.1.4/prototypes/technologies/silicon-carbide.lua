TECHNOLOGY {
    type = "technology",
    name = "silicon-carbide",
    icon = "__pyalienlifegraphics2__/graphics/technology/sic.png",
    icon_size = 128,
    order = "c-a",
    effects = {},
    unit = {
        count = 100,
        ingredients = {
            {"automation-science-pack", 1},
            {"logistic-science-pack", 1},
        },
        time = 50
    }
}
