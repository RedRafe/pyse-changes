TECHNOLOGY {
    type = "technology",
    name = "latex",
    icon = "__pyalienlifegraphics2__/graphics/technology/latex.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    dependencies = {"sap-mk01", "seaweed-mk01"},
    effects = {},
    unit = {
        count = 50,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 30
    }
}
