TECHNOLOGY {
    type = "technology",
    name = "rendering",
    icon = "__pyalienlifegraphics__/graphics/technology/rendering.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"biotech-mk01"},
    effects = {},
    unit = {
        count = 150,
        ingredients = {
            {"automation-science-pack", 3},
        },
        time = 45
    }
}
