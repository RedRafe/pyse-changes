TECHNOLOGY {
    type = "technology",
    name = "crusher-2",
    icon = "__pycoalprocessinggraphics__/graphics/technology/crusher.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {},
    effects = {},
    unit = {
        count = 25,
        ingredients = {
            {"automation-science-pack", 3},
            {"py-science-pack-1", 1}
        },
        time = 55
    }
}
