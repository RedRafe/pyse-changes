TECHNOLOGY {
    type = "technology",
    name = "zoology",
    icon = "__pyalienlifegraphics__/graphics/technology/zoology.png",
    icon_size = 128,
    order = "c-a",
    prerequisites = {"vrauks","rendering"},
    effects = {},
    unit = {
        count = 200,
        ingredients = {
            {"automation-science-pack", 1},
        },
        time = 50
    }
}
