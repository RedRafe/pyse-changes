data:extend(
{
  {
    type = "fuel-category",
    name = "food"
  },
  {
    type = "fuel-category",
    name = "auog"
  },
  {
    type = "fuel-category",
    name = "dingrits"
  },
  {
    type = "fuel-category",
    name = "simik"
  },
}
)
