data:extend(
{
    {
        type = "module-category",
        name = "tree"
    },
    {
        type = "module-category",
        name = "seaweed"
    },
    {
        type = "module-category",
        name = "moss"
    },
    {
        type = "module-category",
        name = "sap"
    },
    {
        type = "module-category",
        name = "ulric" --!!!
    },
    {
        type = "module-category",
        name = "sponge"
    },
    {
        type = "module-category",
        name = "ralesia" --!!!
    },
    {
        type = "module-category",
        name = "mukmoux" --!!!
    },
    {
        type = "module-category",
        name = "tuuphra"
    },
    {
        type = "module-category",
        name = "arthurian"
    },
    {
        type = "module-category",
        name = "navens"
    },
    {
        type = "module-category",
        name = "yotoi"
    },
    {
        type = "module-category",
        name = "rennea"
    },
    {
        type = "module-category",
        name = "dhilmos"
    },
    {
        type = "module-category",
        name = "scrondrix"
    },
    {
        type = "module-category",
        name = "phadai"
    },
    {
        type = "module-category",
        name = "auog"
    },
    {
        type = "module-category",
        name = "fish"
    },
    {
        type = "module-category",
        name = "yaedols"
    },
    {
        type = "module-category",
        name = "dingrits"
    },
    {
        type = "module-category",
        name = "kmauts"
    },
    {
        type = "module-category",
        name = "vonix"
    },
    {
        type = "module-category",
        name = "grod"
    },
    {
        type = "module-category",
        name = "phagnot"
    },
    {
        type = "module-category",
        name = "bhoddos"
    },
    {
        type = "module-category",
        name = "arqad"
    },
    {
        type = "module-category",
        name = "xeno"
    },
    {
        type = "module-category",
        name = "kicalk"
    },
    {
        type = "module-category",
        name = "cridren"
    },
    {
        type = "module-category",
        name = "antelope"
    },
    {
        type = "module-category",
        name = "zipir"
    },
    {
        type = "module-category",
        name = "trits"
    },
    {
        type = "module-category",
        name = "arum" --!!!
    },
    {
        type = "module-category",
        name = "vrauks"
    },
    {
        type = "module-category",
        name = "xyhiphoe" --!!!
    },
    {
        type = "module-category",
        name = "korlex"
    },
    {
        type = "module-category",
        name = "fawogae" --!!!
    },
    {
        type = "module-category",
        name = "moondrop"
    },
    {
        type = "module-category",
        name = "cottongut"
    },
    {
        type = "module-category",
        name = "guar"
    },
    {
        type = "module-category",
        name = "simik",
    },
    {
        type = "module-category",
        name = "zungror",
    },
    {
        type = "module-category",
        name = "vatbrain",
    },
    {
        type = "module-category",
        name = "digosaurus"
    },
})
